import java.util.Scanner;

public class atividade12 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int opcao;
        do {
            System.out.println("\nMenu Principal:");
            System.out.println("1 - Cadastrar Usuário");
            System.out.println("2 - Atualizar Cadastro");
            System.out.println("3 - Cadastrar Produto");
            System.out.println("4 - Excluir Produto");
            System.out.println("5 - Sair");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine(); // Limpa o buffer
            switch (opcao) {
                case 1:
                    System.out.println("Recurso: Cadastrar Usuário");
                    break;
                case 2:
                    System.out.println("Recurso: Atualizar Cadastro");
                    break;
                case 3:
                    System.out.println("Recurso: Cadastrar Produto");
                    break;
                case 4:
                    System.out.println("Recurso: Excluir Produto");
                    break;
                case 5:
                    System.out.println("Encerrando o programa...");
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
            }
        } while (opcao != 5);
        scanner.close();
    }
}
