import java.util.Scanner;

public class atividade4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite o primeiro valor: ");
        int valor1 = scanner.nextInt();
        System.out.print("Digite o segundo valor: ");
        int valor2 = scanner.nextInt();
        int multiplicacao = valor1 * valor2;
        System.out.println("A multiplicação dos valores é: " + multiplicacao);
        scanner.close();
    }
}
