import java.util.Scanner;

public class atividade11 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Menu da Máquina de Café:");
        System.out.println("1 - Café Expresso");
        System.out.println("2 - Café com Leite");
        System.out.println("3 - Cappuccino");
        System.out.println("4 - Café Americano");
        System.out.print("Escolha o tipo de café (1-4): ");
        int escolha = scanner.nextInt();
        String tipoCafe;
        switch (escolha) {
            case 1:
                tipoCafe = "Café Expresso";
                break;
            case 2:
                tipoCafe = "Café com Leite";
                break;
            case 3:
                tipoCafe = "Cappuccino";
                break;
            case 4:
                tipoCafe = "Café Americano";
                break;
            default:
                tipoCafe = "Opção inválida";
        }
        System.out.println("Você escolheu: " + tipoCafe);
        scanner.close();
    }
}
