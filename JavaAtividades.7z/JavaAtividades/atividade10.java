public class atividade10 {
    public static void main(String[] args) {
        System.out.println("Números pares entre 1 e 50:");
        for (int i = 2; i <= 50; i += 2) {
            System.out.println(i);
        }
    }
}
